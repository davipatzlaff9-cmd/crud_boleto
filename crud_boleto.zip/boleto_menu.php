<?php 
/*
* Código de exemplo da utilização de PDO como persistencia
* Página responsável pelo menu da aplicação de boletos
* @author Wesley R. Bezerra
* @version 0.1
*
*/
?>
<hr></hr>
<nav>
    <ul>
        <li>Exemplo de cadastro de boletos</li>
    </ul>
    <ul>
        <li><a href="boleto_cad.php" role="button">Cad.Boleto</a></li>
        <li><a href="boleto_index.php" role="button">List.Boleto</a></li>
    </ul>
</nav>
<hr></hr>
