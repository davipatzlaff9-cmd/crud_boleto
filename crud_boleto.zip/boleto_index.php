
<?php
/*
 * Código de exemplo da utilização de PDO como persistencia
 * Página responsável pela listagem da entidade Boleto
 * @author Wesley R. Bezerra
 * @version 0.1
 *
 */
?>
<!DOCTYPE html>
<html lang="pt-BR" data-theme="ligth">
<?php include 'cabecalho.php'; ?>
<?php require_once 'boleto_acao.php'; ?>

<body>
    <main class="container">
        <?php include 'boleto_menu.php'; ?>
        <?php

        $dao = PDOBoletoDAO::getInstance();
        $dados = array();
        $dados = $dao->listar();

        if (($dados == NULL) || (count($dados) == 0)) {
            echo "<div><span class='warning'>sem dados a serem exibidos</span></div>";
        }
        ?>

        <table role="grid">
            <tr>
                <th>Id</th>
                <th>Data de vencimento</th>
                <th>Data de emissão</th>
                <th>Data de pagamento</th>
                <th>Valor</th>
                <th>Desconto</th>
                <th>Juros</th>
                <th>Multa</th>
                <th>Mora</th>
                <th>Valor pago</th>
                <th>Alterar</th>
                <th>Excluir</th>
            </tr>

            <?php
            foreach ($dados as $key)
                echo "<tr>
                    <td>{$key['id']}</td>
                    <td>{$key['data_vencimento']}</td>
                    <td>{$key['data_emissao']}</td>
                    <td>{$key['data_pagamento']}</td>
                    <td>{$key['valor']}</td>
                    <td>{$key['desconto']}</td>
                    <td>{$key['juros']}</td>
                    <td>{$key['multa']}</td>
                    <td>{$key['mora']}</td>
                    <td>{$key['valor_pago']}</td>
                    <td align='center'>
                        <a role='button' href='boleto_cad.php?id=" . $key['id'] . "'>A</a>
                    </td>
                    <td align='center'>
                        <a role='button' href=\"javascript:excluirRegistro('boleto_acao.php?acao=excluir&id=" . $key['id'] . "');\">E</a>
                    </td>
                </tr>";
            ?>
        </table>
    </main>

    <!-- função de confirmação em javascript para a exclusão -->
    <script>
        function excluirRegistro(url) {
            if (confirm("Confirmar Exclusão?"))
                location.href = url;
        }
    </script>
</body>

</html>
